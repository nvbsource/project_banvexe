"use strict";

var KTHome = (function () {
    var initHome = function () {

    };

    return {
        init: function () {
            initHome();
        },
    };
})();

$(document).ready(function () {
    KTHome.init();
});
